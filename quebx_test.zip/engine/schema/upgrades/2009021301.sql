-- Changing the ACLs on existing groups
UPDATE `prefix_entities` SET access_id=2 WHERE type='group';